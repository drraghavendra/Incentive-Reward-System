import React from 'react';
import Button from '../../Button/Button';
import './SubsidyToken.css';

const SubsidyToken = ({current, token, setToken, onClickCreateSample}) => {
    return (
        <div></div>
        //  <div id="cards_landscape_wrap-2">
        //     <div className="container">
        //         <div className="row">
        //             <div className="col-xs-12 col-sm-6 col-md-3 col-lg-3">
        //                 <a href="">
        //                     <div className="card-flyer">
        //                         <div className="text-box">
        //                             {/* <div className="image-box">
        //                                 <img src={current.img} alt="" />
        //                             </div>
        //                             <div className="text-container">
        //                                 <h6>{current.name}</h6>
        //                             </div> */}
        //                             {/* <div className="btn-container">
        //                                 <Button current={current} token={token} setToken={setToken} onClickCreateSample={onClickCreateSample}/>
        //                             </div> */}
        //                         </div>
        //                     </div>
        //                 </a>
        //             </div>
        //         </div>
        //     </div>
        // </div>            
    )
}

export default SubsidyToken;
