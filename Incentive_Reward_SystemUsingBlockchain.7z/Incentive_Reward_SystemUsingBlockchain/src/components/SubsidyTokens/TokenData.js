export const MyTokens = [
    {
        id:1,
        name:'Cash Subsidy',
        tokenName:'CASHSUB',
        tokenSymbol:'CSH',
        img:'https://www.pngitem.com/pimgs/m/174-1748919_cash-png-animated-cartoon-stacks-of-money-png.png',
    },
    {
        id:2,
        name:'Laptop',
        tokenName:'LAPSUB',
        tokenSymbol:'LTP',
        img:'https://creazilla-store.fra1.digitaloceanspaces.com/cliparts/59577/laptop-file-folders-clipart-sm.png'
    },
    {
        id:3,
        name:'Bicycle',
        tokenName:'CYCSUB',
        tokenSymbol:'CYS',
        img:'https://thumbs.dreamstime.com/b/cartoon-bicycle-happy-colorful-illustration-children-56520771.jpg'
    },
];