# Blockchain_hackathon
Building a webapp which acts as a reward distribution portal where tokens are generated which can later be encashed for various commodities 
![image](https://user-images.githubusercontent.com/86458423/213895304-bf5e6af0-4e4b-4752-bb6c-81e98095b77c.png)
![image](https://user-images.githubusercontent.com/86458423/213895307-25f48634-e9b5-48c0-8ee6-7856e02c839f.png)
![image](https://user-images.githubusercontent.com/86458423/213895310-3deb2fcb-c152-4093-a09e-524e9884c265.png)
![image](https://user-images.githubusercontent.com/86458423/213895315-cb03fdf1-ef50-4bd9-913f-66c581e10ff4.png)
![image](https://user-images.githubusercontent.com/86458423/213895320-9d3670f2-40ad-4254-bd05-9d81d2d50d42.png)
